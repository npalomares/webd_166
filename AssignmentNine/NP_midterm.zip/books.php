<?php 

	define('TITLE', 'Books by J.D. Salinger');

	include('includes/header.php');
?>

	
	<!-- Include sidebar -->
	<?php include('includes/aside.php'); ?>


		<h2>J.D. Salinger's Books</h2>
		<ul>
			<li>The Catcher in the Rye</li>
			<li>Nine Stories</li>
			<li>Franny and Zooey</li>
			<li>Raise High the Roof Beams, Carpenters and Seymour: An Introduction</li>
		</ul>
	
	<?php include('includes/footer.php'); ?>
