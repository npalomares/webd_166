<aside id="sidebar">
	<h2>Favorite Quotes</h2>
		<p class="news">I don't exactly know what I mean by that, but I mean it.<br>- <em>The Catcher in the Rye</em></p>
		<p class="news">I privately say to you, old friend... please accept from me this unpretentious bouquet of early-blooming parentheses: (((()))).<br>- <em>Raise High the Roof Beam, Carpenters and Seymour: An Introduction</em></p>
		<p><?php 
			date_default_timezone_set('America/Los_Angeles'); 
			// print the date
			print date('g:i a l F j')
			?>
		</p>
</aside><!-- sidebar -->


<section id="content">
	<article>
		<!-- BEGIN CHANGEABLE CONTENT. -->