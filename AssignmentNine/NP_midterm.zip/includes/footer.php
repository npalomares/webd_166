		<!-- END CHANGEABLE CONTENT. -->
	    </article>
	</section><!-- content -->

	<footer>
		<p>Template design by <a href="http://www.sixshootermedia.com">Six Shooter Media</a>.</p>
		<p>&copy; <?php echo date('Y'); ?></p>
	</footer><!-- footer -->

</div><!-- wrapper -->
</body>
</html>
<?php 
	ob_end_flush();
?>