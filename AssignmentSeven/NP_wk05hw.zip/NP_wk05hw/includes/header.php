<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Variables</title>
    <link href="css/style.css" rel="stylesheet">
    <script src="js/jquery.js"></script>
</head>
<header>
    <div class="container">
        <h1>NPalomares</h1>
    </div>
</header>    