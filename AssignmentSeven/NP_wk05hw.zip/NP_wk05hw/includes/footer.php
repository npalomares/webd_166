
<footer>
    <div class="container">
        <p class="text-center"><?php echo Date('Y'); ?> Powered by PHP</p>
    </div>
</footer>

</body>
</html>