<?php
/*********************************************************************************
Course:  WEBD166 - PHP

Created 2016: Larry Ullman (PHP for the Web - Fifth Edition)
Modified 2016-11-27 [David Taniguchi]: Modified for PDO Database Connection 

*********************************************************************************/
try {
	/* final: Modify the database connector for your database */
	$db = new PDO('mysql:host=myhost;dbname=mydb;charset=utf8','myuser','mypass');
	// var_dump($db); // Used for debugging
}
catch (Exception $e) {
	echo '<p>WEBD166: Database Error</p>';
}
?>