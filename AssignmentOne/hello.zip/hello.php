<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hello World!</title>
</head>
<body>
	<div class="wrapper">
		<?php print Date('Y-m-d'); ?>
		<p>The following was created by PHP:<br>

		<?php
			/*
			* Filename: hello.php
			* Book reference: Script 1.5
			* Created by: Nicholas Palomares
			*/

			print '<span class="bold">Hello, world!</span>';
			print '</p>';

			// create the code to display name, interests, & hobbies
			print '<p><strong>Nicholas Palomares</strong></p>';
			print '<p>I really enjoy coding and learning new web technologies. When i"m not in front of a computer, I like to be outside breathing in the fresh air. Any kind of sporting activities, especially swimming in the ocean is a must!</p>';
		?>	

	</div>
</body>
</html>
